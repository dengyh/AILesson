Run the program:
make
./main